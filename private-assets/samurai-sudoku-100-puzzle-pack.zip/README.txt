100 Samurai Sudoku Printable Puzzles

Included:
- 100 puzzles: 25 Easy, 25 Medium, 25 Hard, and 25 Evil
- Complete answer keys
- A4 and US Letter PDF editions
- One-puzzle-per-page and two-puzzles-per-page layouts
- Vector black-and-white layouts for clear printing

License: personal and classroom use. Do not resell or redistribute this pack.
Support: feedback@samuraisudoku.net
Website: https://www.samuraisudoku.net/en/games/samurai/pdf
